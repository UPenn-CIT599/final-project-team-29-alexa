
public class getMeaningTest {

}
